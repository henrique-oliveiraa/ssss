//Isso é só pra testar eu acho né????
package appEnderecoCEP;

import appEnderecoCEP.BuscadorCep;


public class AppEnderecoCep {

    
    public static void main(String[] args) {
        String cep = "93315130";
        BuscadorCep op = new BuscadorCep();
        
        
        
    }
    
}