package DAL;

import Model.ClienteModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class OperTesteOrdemServ {
    
    //talvez fazer depois
    public String pesquisarNome(){
        return null;    
    }

    
    public String pesquisarID(){
        return null;
    }
    
    
    public ArrayList<ClienteModel> pesquisarPorID(String ClienteID) {
        String sql = "select * from TB_CLIENTES where ID_CLIENTE = ?";
        PreparedStatement pst = null;
        Connection connection = null;
        ResultSet rs = null;
        ArrayList<ClienteModel> listaClientes = new ArrayList<ClienteModel>();
        ClienteModel cliente = null;
        
        try {
            connection = new ConnectionFactory().getConnection();
            pst = connection.prepareStatement(sql);
            pst.setString(1, ClienteID);
            rs = pst.executeQuery();
            if (rs != null) {
                while (rs.next()) {
                    cliente = new ClienteModel();
                    cliente.setId(rs.getString("ID_CLIENTE"));
                    cliente.setClientName(rs.getString("NOME_CLIENTE"));
                    cliente.setAdress(rs.getString("ENDERECO_CLIENTE"));
                    listaClientes.add(cliente);
                }
            }

            System.out.println("Registros ***RECUPERADO*** com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ERRO::DAL::LISTAR_REGISTROS");
        } finally {
            try {
                if (pst != null) {
                    pst.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }

            //Exemplo: desligamos o telefone (encerramos a ligação)
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }
        }
        return listaClientes;
    
    
        
    }

    
}
    
