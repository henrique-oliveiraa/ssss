package DAL;

import Model.ClienteModel;
import Model.OrdServModel;
import Model.UsuarioModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class OperInsereRegistroBD {

    //1. Método de inserir registros
    public void inserirRegistro(UsuarioModel novoUsuario) {

        String sql = "insert into TB_USERS (USER_NAME, EMAIL, LOGIN, PASSWORD, PERFIL_USER) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement pst = null;
        Connection connection = null;

        try {
            connection = new ConnectionFactory().getConnection();
            pst = connection.prepareStatement(sql);
            pst.setString(1, novoUsuario.getUserName());
            pst.setString(2, novoUsuario.getEmail());
            pst.setString(3, novoUsuario.getLogin());
            pst.setString(4, novoUsuario.getPassword());
            pst.setString(5, novoUsuario.getPerfil());
            pst.executeUpdate();
            System.out.println("O registro foi inserido com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ERRO::DAL::INSERIR_REGISTRO");
        } finally {
            //Exemplo: agradece pela execução e diz: "tchau!"
            try {
                if (pst != null) {
                    pst.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }

            //Exemplo: desligamos o telefone (encerramos a ligação)
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }
        }
    }
    
    // Terminar de arrumar caso n tenha terminado :)
    public void inserirRegistroCliente(ClienteModel novoCliente){ 
        
        String sql = "insert into TB_CLIENTES (NOME_CLIENTE, CEP_CLIENTE, ENDERECO_CLIENTE, FONE_CLIENTE, EMAIL_CLIENTE) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement pst = null;
        Connection connection = null;

        try {
            connection = new ConnectionFactory().getConnection();
            pst = connection.prepareStatement(sql);
            pst.setString(1, novoCliente.getClientName());
            pst.setString(2, novoCliente.getCEP());
            pst.setString(3, novoCliente.getAdress());
            pst.setString(4, novoCliente.getPhoneNumb());
            pst.setString(5, novoCliente.getEmail());
            pst.executeUpdate();
            System.out.println("O registro foi inserido com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ERRO::DAL::INSERIR_REGISTRO");
        } finally {
            //Exemplo: agradece pela execução e diz: "tchau!"
            try {
                if (pst != null) {
                    pst.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }

            //Exemplo: desligamos o telefone (encerramos a ligação)
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }
        }
    
    }
    
    public void inserirRegistroOrdServ(OrdServModel novaOrdServ){ 
        
        String sql = "insert into TB_ORDSERV (EQUIPAMENTO, DEFEITO, SERVICO, TECNICO, VALOR, ID_CLIENTE) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement pst = null;
        Connection connection = null;

        try {
            connection = new ConnectionFactory().getConnection();
            pst = connection.prepareStatement(sql);
            pst.setString(1, novaOrdServ.getEquip());
            pst.setString(2, novaOrdServ.getDescDefeito());
            pst.setString(3, novaOrdServ.get());
            pst.setString(4, novaOrdServ.getTecnico());
            pst.setString(5, novaOrdServ.getValor());
            pst.setString(6, novaOrdServ.getIdClient());
            pst.executeUpdate();
            System.out.println("O registro foi inserido com sucesso!");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ERRO::DAL::INSERIR_REGISTRO");
        } finally {
            //Exemplo: agradece pela execução e diz: "tchau!"
            try {
                if (pst != null) {
                    pst.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }

            //Exemplo: desligamos o telefone (encerramos a ligação)
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException sQLException) {
                sQLException.printStackTrace();
            }
        }
    
    }
}
