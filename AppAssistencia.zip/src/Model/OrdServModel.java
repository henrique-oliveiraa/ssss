
package Model;

import DAL.OperTesteOrdemServ;
import java.util.ArrayList;

public class OrdServModel {
    
    public String id;
    public String endereco;
    public String equip;
    public String descDefeito;
    public String tecnico;
    public String Valor;
    public String idClient;

   
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getEquip() {
        return equip;
    }

    public void setEquip(String equip) {
        this.equip = equip;
    }

   
    public String getDescDefeito() {
        return descDefeito;
    }

    public void setDescDefeito(String descDefeito) {
        this.descDefeito = descDefeito;
    }

    public String getTecnico() {
        return tecnico;
    }

    public void setTecnico(String tecnico) {
        this.tecnico = tecnico;
    }

    public String getValor() {
        return Valor;
    }

    public void setValor(String Valor) {
        this.Valor = Valor;
    }

    public String getIdClient() {
        return idClient;
    }

    public void setIdClient(String idClient) {
        this.idClient = idClient;
    }
    

    public ArrayList<ClienteModel> pesquisarPorIDModel(String idClient){
        OperTesteOrdemServ op = new OperTesteOrdemServ();
        return op.pesquisarPorID(idClient);
    
    }
    
}

