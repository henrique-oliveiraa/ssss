
package Controller;

import DAL.OperTesteOrdemServ;
import Model.ClienteModel;
import Model.OrdServModel;
import java.util.ArrayList;

public class OrdServController {
    
    public ArrayList<ClienteModel> pesquisarPorIDController(String idClient){
        OrdServModel op = new OrdServModel();
        return op.pesquisarPorIDModel(idClient);
    }
    
}
