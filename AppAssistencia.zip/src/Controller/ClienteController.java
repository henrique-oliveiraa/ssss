package Controller;

import Model.ClienteModel;
import java.util.ArrayList;

public class ClienteController {

    public ArrayList<ClienteModel> listarRegistrosController() {
        ClienteModel op = new ClienteModel();
        return op.listarRegistrosModel();
    }
    
    /*public ArrayList<ClienteModel> filtrarRegistrosController(String nome) {
        UsuarioModel op = new UsuarioModel();
        return op.filtrarRegistrosModel(nome);
    }*/
    
    //Método que vai enviar as informações recebidas
    // da tela de interface gráfica para o método de inserir
    // registro contido no model.
    public void inserirRegistroController(String clientName, String CEP, String Adress, String phoneNumb, String email){
        ClienteModel novoUsuario = new ClienteModel(clientName, CEP, Adress, phoneNumb, email);
        novoUsuario.inserirRegistrosModel(novoUsuario);
    }
    
    //Método no controller que obtenha a informação do ID para a exclusão
    public void excluirRegistroController(String idCliente){
        ClienteModel op = new ClienteModel();
        op.excluirRegistrosModel(idCliente);
    }
    
    //Método no controller que obtenha as informações atualizadas | UPDATE
    public void atualizarRegistroController(String id,String clientName, String CEP, String Adress, String phoneNumb, String email){
        ClienteModel clienteAtualizado = new ClienteModel(id, clientName, CEP, Adress, phoneNumb, email);
        clienteAtualizado.atualizarRegistrosModel(clienteAtualizado);
    }
    
    
}
